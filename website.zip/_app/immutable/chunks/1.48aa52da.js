import{default as t}from"../entry/error.svelte.ae45d4eb.js";export{t as component};
