import{default as t}from"../entry/_page.svelte.6adc57bf.js";export{t as component};
